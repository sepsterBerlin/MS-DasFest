// src/App.jsx
// Paste your full MS-DAS UI code here (the one with menu, Box Office, etc.)

export default function App() {
  return (
    <div className="min-h-screen bg-black text-green-400 p-4 font-mono">
      <h1>MS‑DAS Web</h1>
      <p>Replace this with the full App.jsx code.</p>
    </div>
  );
}
